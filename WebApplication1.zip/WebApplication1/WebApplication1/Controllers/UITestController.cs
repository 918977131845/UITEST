﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using Newtonsoft.Json;
using WebApplication1.Models;
using System.Web.UI.WebControls;

namespace WebApplication1.Controllers
{
    public class UITestController : Controller
    {
        // GET: UITest
        public ActionResult Index()
        {
            return View();
        }

        
        [HttpPost]
        public ActionResult  Import(HttpPostedFileBase jsonFile)
        {
            Root datalist = null;
            if (!jsonFile.FileName.EndsWith(".json")) 
            {
                ViewBag.Error = "Please upload the Valid File";
            }
            else
            {
                Random rnd = new Random();
                string filename = "~/JsonFiles/"+ rnd .Next()+ Path.GetFileName(jsonFile.FileName);
                jsonFile.SaveAs(Server.MapPath(filename));

                StreamReader streamReader = new StreamReader(Server.MapPath(filename));
                string data= streamReader.ReadToEnd();

               datalist = JsonConvert.DeserializeObject<Root>(data);

            }
            return Json(datalist, JsonRequestBehavior.AllowGet);
        }
    }
}